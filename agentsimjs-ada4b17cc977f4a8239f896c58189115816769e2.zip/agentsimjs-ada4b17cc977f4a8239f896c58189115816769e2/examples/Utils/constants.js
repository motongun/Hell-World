window.UP="UP";
window.DOWN="DOWN";
window.LEFT="LEFT";
window.RIGHT="RIGHT";
window.consoleLogisEnable="true";